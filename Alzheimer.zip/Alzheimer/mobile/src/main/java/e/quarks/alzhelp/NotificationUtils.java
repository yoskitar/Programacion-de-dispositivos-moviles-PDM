package e.quarks.alzhelp;

public class NotificationUtils {
    public final static String EXTRA_VOICE_REPLY = "extra_voice_reply";
}
