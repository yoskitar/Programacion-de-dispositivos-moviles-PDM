package e.quarks.whoismore;

public enum Status {
    CREATED, INITIALIZED, FINISHED;
}
